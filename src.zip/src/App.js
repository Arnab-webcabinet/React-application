import './App.scss';
import Loginpage from './components/loginpage';

function App() {
  return (
    <Loginpage />
  );
}

export default App;