import React from 'react'
import logo from '../images/logomain.png';
import { Container, Row, Col } from 'react-bootstrap';
//import ReCAPTCHA from "react-google-recaptcha";


export default function Loginpage({title}) {
  return (
    <section className="login-page text-center">
      <Container>
      <Row className="vh-100 align-items-center">
        <Col xs={12} md={8} className='text-left'>
          <img src={logo} alt="logo" className='logo-img' />
          <h1>Efficiency starts here.</h1>
          <h4>Get ready to accelerate your business with us.</h4>
        </Col>
        <Col xs={6} md={4}>
          <div className="card p-4 login-panel">
            <h3 className="card-title text-center">Sign In</h3>
            <p>Welcome back! Please enter your details</p>
            <form>
              <div className="mb-3 text-left">
                <label htmlFor="email" className="form-label text-left">Username*</label>
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  value="email"
                />
              </div>
              <div className="mb-3 text-left">
                <label htmlFor="password" className="form-label">Password*</label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  value="password"
                  required
                />
              </div>
              <div className="mb-3 text-left">
                <label htmlFor="bootstrapSelect" className="form-label text-left">Select Unit*</label>
                <select value="unit" className="form-control">
                  <option value="">Select Unit</option>
                  <option value="admin">Admin</option>
                  <option value="user">User</option>
                  <option value="guest">Guest</option>
                  <option value="guest">Guest 2</option>
                </select>
              </div>
              <div className="mb-3">
                <label htmlFor="captcha" className="form-label">
                  What is?
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="captcha"
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary w-100">Login</button>
            </form>
          </div>
        </Col>
        </Row>
      </Container>
      </section>
  )
}
